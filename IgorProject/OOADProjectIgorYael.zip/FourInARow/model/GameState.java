package FourInARow.model;

public enum GameState {

	PROGRESS, WON, DRAW, ILLEGAL
}

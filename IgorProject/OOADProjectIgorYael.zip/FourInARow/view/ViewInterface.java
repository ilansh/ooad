package FourInARow.view;

public interface ViewInterface {

}

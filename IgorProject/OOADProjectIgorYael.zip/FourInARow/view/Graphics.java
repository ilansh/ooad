package FourInARow.view;

//import FourInARow.board.BoardInterface;

public interface Graphics {

	
	public Object drawGraphics(int[][] board);

	public void addGraphics(Graphics board);
	
}

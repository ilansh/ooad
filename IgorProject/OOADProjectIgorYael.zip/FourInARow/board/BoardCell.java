package FourInARow.board;

public enum BoardCell {
	//igor
	EMPTY, COLORONE, COLORTWO
}

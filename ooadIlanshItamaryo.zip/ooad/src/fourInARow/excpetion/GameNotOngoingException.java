package fourInARow.excpetion;

public class GameNotOngoingException extends Exception {

}

package fourInARow.excpetion;

public class InvalidPlayerNumException extends Exception {

}

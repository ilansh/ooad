package fourInARow.excpetion;

public class NotEnoughPlayersException extends Exception {

}

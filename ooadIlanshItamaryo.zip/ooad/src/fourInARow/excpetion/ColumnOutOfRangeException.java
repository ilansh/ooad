package fourInARow.excpetion;

public class ColumnOutOfRangeException extends Exception {

}

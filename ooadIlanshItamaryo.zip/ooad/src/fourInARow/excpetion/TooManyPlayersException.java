package fourInARow.excpetion;

public class TooManyPlayersException extends Exception {

}

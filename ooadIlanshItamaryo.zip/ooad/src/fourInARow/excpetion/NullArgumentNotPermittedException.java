package fourInARow.excpetion;

public class NullArgumentNotPermittedException extends Exception {

}

package fourInARow.excpetion;

public class NoViewsConfiguredException extends Exception {

}

package fourInARow.excpetion;

public class ColumnFullException extends Exception {
	
}

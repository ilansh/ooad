package fourInARow.model;


public enum GameStatus {
	NOT_INIT, WIN, DRAW, ONGOING
}
